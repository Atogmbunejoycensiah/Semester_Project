#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

class Contact {
public:
    Contact(const string& name, const string& phoneNumber)
        : name(name), phoneNumber(phoneNumber) {}

    string getName() const { return name; }
    string getPhoneNumber() const { return phoneNumber; }

private:
    string name;
    string phoneNumber;
};

class Phonebook {
public:
    void addContact(const Contact& contact) {
        contacts.push_back(contact);
    }

    void searchByName(const string& name) {
        cout << "Search results " << endl;
        for (const Contact& contact : contacts) {
            if (contact.getName().find(name) != string::npos) {
                cout << "\n Name: " << contact.getName() << "\n Phone: " << contact.getPhoneNumber() << endl;
            }
        }
    }

    void sortContacts() {
        sort(contacts.begin(), contacts.end(), [](const Contact& a, const Contact& b) {
            return a.getName() < b.getName();
        });
    }

private:
    vector<Contact> contacts;
};

int main() {
    Phonebook phonebook;
    
    cout<<" Welcome to Joyce's phonebook"<<endl;

    phonebook.addContact(Contact("Justin", "024-456-7890"));
    phonebook.addContact(Contact("Frimps", "027-654-3210"));
    phonebook.addContact(Contact("Frimps 2", "527-654-3210"));
    phonebook.addContact(Contact("Eunice", "056-654-3210"));
    phonebook.addContact(Contact("Yaa Babe", "055-654-3210"));
    phonebook.addContact(Contact("Prince", "055-123-4567"));
    phonebook.addContact(Contact("Caleb", "020-123-4567"));
    phonebook.addContact(Contact("Prince", "050-898-4567"));
    phonebook.addContact(Contact("Caleb A", "050-245-4567"));
    phonebook.addContact(Contact("Gloria", "055-245-4567"));
    phonebook.addContact(Contact("Peter", "050-988-4567"));

    phonebook.sortContacts();

    string searchName;
    cout << "\n Enter any of the above name to search for their contact: ";
    cin >> searchName;
    system ("cls");

    phonebook.searchByName(searchName);

    return 0;
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
